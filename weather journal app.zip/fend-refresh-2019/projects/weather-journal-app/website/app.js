/* Global Variables */
const key = `eead32de6d9b50235afac4a42911e565`
const baseURL = `https://api.openweathermap.org/data/2.5/weather?zip=`
let d = new Date();
let newDate = `${d.getMonth() + 1}.${d.getDate()}.${d.getFullYear()}`;
const feeling = document.getElementById('content')
const currentDate = document.getElementById('date')
const temp = document.getElementById('temp')
const userFeeling = document.getElementById('feelings')
const generateButton = document.getElementById('generate')
const zipCode = document.getElementById('zip')
// creating get request to the openweather API
async function getData(URL) {
    // wait for the request to get data
    const req = await fetch(URL)
    // if everything work good preform the following =>"try"
    try {
        const res = await req.json()
        return res
        // if something went wrong console.log the error
    } catch (error) {
        console.log(error)
    }
}
// creating post request to the local server
async function postData(data) {
    // wait for the request to post data
    const req = await fetch('/postinfo',
        // the type of request we want to make
        {
            method: 'POST',
            credentials: 'same-origin',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(data),
        })
    try {
        const res = await req.json()
        return res
    } catch (error) {
        // handling error
        console.log(error)
    }
}
// Update UI
async function updateUI() {
    // wait for get request from locoal server
    const req = await fetch('/getinfo')
    try {
        const res = await req.json()
        // updating elements
        temp.innerHTML = `temp:${res.temp}`;
        currentDate.innerHTML = `date:${res.date}`;
        feeling.innerHTML = `feeling:${res.feeling}`;
    } catch (error) {
        // handling error
        console.log(error)
    }
}
// invoking functions when clicking generate button
generateButton.addEventListener('click', async function preformACTION() {
    // invoking the getData() function to get tempreture then post the temp to the local server using ".then" property 
    // also post date and feeling of user, then update UI =>*chaining promises using ".then" * 
    if (zipCode.value.length < 5 || zipCode.value.length > 5) {
        alert('please enter five numbers only')
    }
    else {
        const URL = `${baseURL}${zipCode.value}&appid=${key}&units=metric`
        getData(URL).then((data) => {
            postData({
                feeling: userFeeling.value,
                temp: data.main.temp,
                date: newDate

            })
        }).then(() => {
            updateUI()
        })
    }
})
